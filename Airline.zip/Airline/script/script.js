function updatePrice() {
    const from = document.getElementById('from').value;
    const to = document.getElementById('to').value;
    const flightClass = document.getElementById('class').value;

    let priceRange = '';
    if (from && to) {
        if (flightClass === 'economy') {
                    switch (`${from}-${to}`) {
                        case 'Manila-Cebu':
                        case 'Cebu-Manila':
                            priceRange = '₱2,000 - ₱3,000';
                            break;
                        case 'Manila-Davao':
                        case 'Davao-Manila':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Manila-Clark':
                        case 'Clark-Manila':
                            priceRange = '₱1,500 - ₱2,500';
                            break;
                        case 'Manila-Iloilo':
                        case 'Iloilo-Manila':
                            priceRange = '₱2,500 - ₱3,500';
                            break;
                        case 'Manila-Kalibo':
                        case 'Kalibo-Manila':
                            priceRange = '₱2,000 - ₱3,000';
                            break;
                        case 'Manila-Tagbilaran':
                        case 'Tagbilaran-Manila':
                            priceRange = '₱3,000 - ₱4,000';
                            break;
                        case 'Manila-Zamboanga':
                        case 'Zamboanga-Manila':
                            priceRange = '₱4,000 - ₱5,000';
                            break;
                        case 'Cebu-Davao':
                        case 'Davao-Cebu':
                            priceRange = '₱3,500 - ₱4,500';
                            break;
                        case 'Cebu-Clark':
                        case 'Clark-Cebu':
                            priceRange = '₱2,000 - ₱3,000';
                            break;
                        case 'Cebu-Iloilo':
                        case 'Iloilo-Cebu':
                            priceRange = '₱2,500 - ₱3,500';
                            break;
                        case 'Cebu-Kalibo':
                        case 'Kalibo-Cebu':
                            priceRange = '₱2,000 - ₱3,000';
                            break;
                        case 'Cebu-Tagbilaran':
                        case 'Tagbilaran-Cebu':
                            priceRange = '₱2,500 - ₱3,500';
                            break;
                        case 'Cebu-Zamboanga':
                        case 'Zamboanga-Cebu':
                            priceRange = '₱3,500 - ₱4,500';
                            break;
                        case 'Davao-Clark':
                        case 'Clark-Davao':
                            priceRange = '₱3,000 - ₱4,000';
                            break;
                        case 'Davao-Iloilo':
                        case 'Iloilo-Davao':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Davao-Kalibo':
                        case 'Kalibo-Davao':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Davao-Tagbilaran':
                        case 'Tagbilaran-Davao':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                        case 'Davao-Zamboanga':
                        case 'Zamboanga-Davao':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        case 'Clark-Iloilo':
                        case 'Iloilo-Clark':
                            priceRange = '₱2,000 - ₱3,000';
                            break;
                        case 'Clark-Kalibo':
                        case 'Kalibo-Clark':
                            priceRange = '₱2,000 - ₱3,000';
                            break;
                        case 'Clark-Tagbilaran':
                        case 'Tagbilaran-Clark':
                            priceRange = '₱2,500 - ₱3,500';
                            break;
                        case 'Clark-Zamboanga':
                        case 'Zamboanga-Clark':
                            priceRange = '₱3,000 - ₱4,000';
                            break;
                        case 'Iloilo-Kalibo':
                        case 'Kalibo-Iloilo':
                            priceRange = '₱2,000 - ₱3,000';
                            break;
                        case 'Iloilo-Tagbilaran':
                        case 'Tagbilaran-Iloilo':
                            priceRange = '₱2,500 - ₱3,500';
                            break;
                        case 'Iloilo-Zamboanga':
                        case 'Zamboanga-Iloilo':
                            priceRange = '₱3,000 - ₱4,000';
                            break;
                        case 'Kalibo-Manila':
                        case 'Manila-Kalibo':
                            priceRange = '₱2,000 - ₱3,000';
                            break;
                        case 'Kalibo-Cebu':
                        case 'Cebu-Kalibo':
                            priceRange = '₱2,000 - ₱3,000';
                            break;
                        case 'Kalibo-Davao':
                        case 'Davao-Kalibo':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Kalibo-Tagbilaran':
                        case 'Tagbilaran-Kalibo':
                            priceRange = '₱2,500 - ₱3,500';
                            break;
                        case 'Kalibo-Zamboanga':
                        case 'Zamboanga-Kalibo':
                            priceRange = '₱3,000 - ₱4,000';
                            break;
                        case 'Tagbilaran-Manila':
                        case 'Manila-Tagbilaran':
                            priceRange = '₱3,000 - ₱4,000';
                            break;
                        case 'Tagbilaran-Cebu':
                        case 'Cebu-Tagbilaran':
                            priceRange = '₱2,500 - ₱3,500';
                            break;
                        case 'Tagbilaran-Davao':
                        case 'Davao-Tagbilaran':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                        case 'Tagbilaran-Clark':
                        case 'Clark-Tagbilaran':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                        case 'Tagbilaran-Iloilo':
                        case 'Iloilo-Tagbilaran':
                            priceRange = '₱2,500 - ₱3,500';
                            break;
                        case 'Tagbilaran-Kalibo':
                        case 'Kalibo-Tagbilaran':
                            priceRange = '₱2,500 - ₱3,500';
                            break;
                        case 'Tagbilaran-Zamboanga':
                        case 'Zamboanga-Tagbilaran':
                            priceRange = '₱4,000 - ₱5,000';
                            break;
                        case 'Zamboanga-Manila':
                        case 'Manila-Zamboanga':
                            priceRange = '₱4,000 - ₱5,000';
                            break;
                        case 'Zamboanga-Cebu':
                        case 'Cebu-Zamboanga':
                            priceRange = '₱3,500 - ₱4,500';
                            break;
                        case 'Zamboanga-Davao':
                        case 'Davao-Zamboanga':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        case 'Zamboanga-Clark':
                        case 'Clark-Zamboanga':
                            priceRange = '₱3,000 - ₱4,000';
                            break;
                        case 'Zamboanga-Iloilo':
                        case 'Iloilo-Zamboanga':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        case 'Zamboanga-Kalibo':
                        case 'Kalibo-Zamboanga':
                            priceRange = '₱3,000 - ₱4,000';
                            break;
                        default:
                            priceRange = '₱2,000 - ₱5,000';
                    }
                } else if (flightClass === 'comfort') {
                    switch (`${from}-${to}`) {
                        case 'Manila-Cebu':
                        case 'Cebu-Manila':
                            priceRange = '₱3,000 - ₱5,000';
                            break;
                        case 'Manila-Davao':
                        case 'Davao-Manila':
                            priceRange = '₱4,500 - ₱6,000';
                            break;
                        case 'Manila-Clark':
                        case 'Clark-Manila':
                            priceRange = '₱2,500 - ₱4,000';
                            break;
                        case 'Manila-Iloilo':
                        case 'Iloilo-Manila':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                            case 'Manila-Kalibo':
                        case 'Kalibo-Manila':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Manila-Tagbilaran':
                        case 'Tagbilaran-Manila':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        case 'Manila-Zamboanga':
                        case 'Zamboanga-Manila':
                            priceRange = '₱5,000 - ₱6,500';
                            break;
                        case 'Cebu-Davao':
                        case 'Davao-Cebu':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        case 'Cebu-Clark':
                        case 'Clark-Cebu':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Cebu-Iloilo':
                        case 'Iloilo-Cebu':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                        case 'Cebu-Kalibo':
                        case 'Kalibo-Cebu':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Cebu-Tagbilaran':
                        case 'Tagbilaran-Cebu':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                        case 'Cebu-Zamboanga':
                        case 'Zamboanga-Cebu':
                            priceRange = '₱4,500 - ₱6,000';
                            break;
                        case 'Davao-Clark':
                        case 'Clark-Davao':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        case 'Davao-Iloilo':
                        case 'Iloilo-Davao':
                            priceRange = '₱4,500 - ₱6,000';
                            break;
                        case 'Davao-Kalibo':
                        case 'Kalibo-Davao':
                            priceRange = '₱4,500 - ₱6,000';
                            break;
                        case 'Davao-Tagbilaran':
                        case 'Tagbilaran-Davao':
                            priceRange = '₱5,000 - ₱6,500';
                            break;
                        case 'Davao-Zamboanga':
                        case 'Zamboanga-Davao':
                            priceRange = '₱6,000 - ₱7,500';
                            break;
                        case 'Clark-Iloilo':
                        case 'Iloilo-Clark':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Clark-Kalibo':
                        case 'Kalibo-Clark':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Clark-Tagbilaran':
                        case 'Tagbilaran-Clark':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                        case 'Clark-Zamboanga':
                        case 'Zamboanga-Clark':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        case 'Iloilo-Kalibo':
                        case 'Kalibo-Iloilo':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Iloilo-Tagbilaran':
                        case 'Tagbilaran-Iloilo':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                        case 'Iloilo-Zamboanga':
                        case 'Zamboanga-Iloilo':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        case 'Kalibo-Manila':
                        case 'Manila-Kalibo':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Kalibo-Cebu':
                        case 'Cebu-Kalibo':
                            priceRange = '₱3,000 - ₱4,500';
                            break;
                        case 'Kalibo-Davao':
                        case 'Davao-Kalibo':
                            priceRange = '₱4,500 - ₱6,000';
                            break;
                        case 'Kalibo-Tagbilaran':
                        case 'Tagbilaran-Kalibo':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                        case 'Kalibo-Zamboanga':
                        case 'Zamboanga-Kalibo':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        case 'Tagbilaran-Manila':
                        case 'Manila-Tagbilaran':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        case 'Tagbilaran-Cebu':
                        case 'Cebu-Tagbilaran':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                        case 'Tagbilaran-Davao':
                        case 'Davao-Tagbilaran':
                            priceRange = '₱5,000 - ₱6,500';
                            break;
                        case 'Tagbilaran-Clark':
                        case 'Clark-Tagbilaran':
                            priceRange = '₱5,000 - ₱6,500';
                            break;
                        case 'Tagbilaran-Iloilo':
                        case 'Iloilo-Tagbilaran':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                        case 'Tagbilaran-Kalibo':
                        case 'Kalibo-Tagbilaran':
                            priceRange = '₱3,500 - ₱5,000';
                            break;
                        case 'Tagbilaran-Zamboanga':
                        case 'Zamboanga-Tagbilaran':
                            priceRange = '₱5,000 - ₱6,500';
                            break;
                        case 'Zamboanga-Manila':
                        case 'Manila-Zamboanga':
                            priceRange = '₱5,000 - ₱6,500';
                            break;
                        case 'Zamboanga-Cebu':
                        case 'Cebu-Zamboanga':
                            priceRange = '₱4,500 - ₱6,000';
                            break;
                        case 'Zamboanga-Davao':
                        case 'Davao-Zamboanga':
                            priceRange = '₱6,000 - ₱7,500';
                            break;
                        case 'Zamboanga-Clark':
                        case 'Clark-Zamboanga':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        case 'Zamboanga-Iloilo':
                        case 'Iloilo-Zamboanga':
                            priceRange = '₱6,000 - ₱7,500';
                            break;
                        case 'Zamboanga-Kalibo':
                        case 'Kalibo-Zamboanga':
                            priceRange = '₱4,000 - ₱5,500';
                            break;
                        default:
                            priceRange = '₱3,000 - ₱7,000';
                    }
                } else {
                    priceRange = '₱2,000 - ₱7,000'; 
                }
            } else {
                priceRange = '₱2,000 - ₱7,000'; 
            }
            
    
    const priceDisplay = document.getElementById('priceDisplay');
    if (priceDisplay) {
        priceDisplay.textContent = priceRange ? `Estimated Price: ${priceRange}` : '';
    }
}

function validateSearchForm() {
    var tripType = document.querySelector('input[name="tripType"]:checked');
    var from = document.getElementById('from').value.trim();
    var to = document.getElementById('to').value.trim();
    var depart = document.getElementById('depart').value.trim();
    var returnDate = document.getElementById('return').value.trim();
    var passengers = document.getElementById('passenger').value.trim();

    // Check if any required fields are empty
    if (!tripType) {
        alert('Please select Trip Type (Round Trip or One Way)');
        return false;
    }
    if (from === '') {
        alert('Please select a departure location');
        return false;
    }
    if (to === '') {
        alert('Please select an arrival location');
        return false;
    }
    if (depart === '') {
        alert('Please select a departure date');
        return false;
    }
    if (tripType.value === 'roundTrip' && returnDate === '') {
        alert('Please select a return date');
        return false;
    }
    if (passengers === '' || passengers <= 0) {
        alert('Please enter number of passengers (minimum 1)');
        return false;
    }
        
    // Validation passed
    return true;
    
}

<?php
    $conn = new mysqli('localhost', 'root', '', 'flight_booking');
    
?>
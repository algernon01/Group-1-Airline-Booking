<?php
session_start();
?>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MCC Airline</title>
    <link rel="icon" href="LOGO.png" type="image/x-icon">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
      integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link rel="stylesheet" href="../css/home.css" />
  </head>
  <body>
    <nav class="navbar">
      <div class="navbar-container container">
          <input type="checkbox" name="" id="">
          <div class="hamburger-lines">
              <span class="line line1"></span>
              <span class="line line2"></span>
              <span class="line line3"></span>
          </div>
          <ul class="menu-items">
              <li><a href="#home">Home</a></li>
              <li><a href="#about">About</a></li>
              <li><a href="#plane">Category</a></li>
              <li><a href="#plane-menu">Menu</a></li>
              <li><a href="#developers">developer</a></li>
              <li><a href="#contact">Contact</a></li>
              <li><a href="redirect.php">Booking</a></li>
              <li><a href="tickets.php">Flights</a></li>
              <li><a href="result.php">Result</a></li>
              <?php if (isset($_SESSION['user'])): ?>
                        <div class="profile">
                            <span><?= $_SESSION['user']; ?></span>
                            <div class="dropdown">
                            <?php
                        include('../Register/connection.php');
                        $user_id = $_SESSION['id'];
                        $sql = "SELECT photo FROM users WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $user_id);
                        $stmt->execute();
                        $stmt->bind_result($photoPath);
                        $stmt->fetch();
                        $stmt->close();
                        $conn->close();
                        
                        $photoPath = $photoPath ?: 'pf.jpeg'; 
                        ?>
                        <img src="<?php echo htmlspecialchars($photoPath); ?>" class="hoverZoomLink" alt="User Photo">
                                <div class="dropdown-content">
                                    <a href="profile.php">Profile</a>
                                    <a href="logout.php">Logout</a>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <li class="login"><a href="../Register/login.php">Login</a></li>
                        <li><a href="../Register/Register.php">Register</a></li>
                    <?php endif; ?>
          </ul>
          <img src="LOGO.png" alt="Logo" id="logo" class ="logo">
      </div>
  </nav>
    <section class="showcase-area" id="showcase">
      <div class="showcase-container">
        <h1 class="main-title" id="home">Welcome TO MCC Airline</h1>
        <a href="#plane-menu" class="btn btn-primary"onclick="window.location.href='redirect.php'">BOOK A FLIGHT NOW!</a>
      </div>
    </section>

    <section id="about">
      <div class="about-wrapper container">
        <div class="about-text">
          <p class="small">About Us</p>
          <h2>Connecting Dreams, One Flight at a Time</h2>
          <p>
          MCC Airlines aims to revolutionize travel in the Philippines by 
          providing exceptional experiences at affordable prices through our
          user-friendly website. Our mission is to enable everyone to explore 
          the Philippines with economical airfares. As the pioneering airline
        of MCC, we proudly cater to all travelers within the Philippines, offering 24/7 booking assistance. We are committed to making travel accessible for all, ensuring that the beauty and diversity of the Philippines are within everyone’s grasp. Our dedication to you includes a seamless travel experience from booking to arrival, supported by our dedicated customer service team.
          </p>
        </div>
        <div class="about-img">
          <img src="../css/Photo.avif" alt="plane" />
        </div>
      </div>
    </section>
    <section id="plane">
      <h2>Plane</h2>
      <div class="plane-container container">
        <div class="plane-type fruite">
          <div class="img-container">
            <img src="../css/plane1.webp" alt="error" />
            <div class="img-content">
              <h3>Plane 1</h3>
              <a
                href="https://myfox8.com/news/airbus-ponders-a-future-with-a-flying-starbucks-and-no-view/"
                class="btn btn-primary"
                target="blank"
                >learn more</a
              >
            </div>
          </div>
        </div>
        <div class="plane-type vegetable">
          <div class="img-container">
            <img src="../css/plane2.jpg" alt="error" />
            <div class="img-content">
              <h3>Plane 2</h3>
              <a
                href="https://skytraxratings.com/airlines/philippine-airlines-rating"
                class="btn btn-primary"
                target="blank"
                >learn more</a
              >
            </div>
          </div>
        </div>
        <div class="plane-type grin">
          <div class="img-container">
            <img src="../css/plane3.jpg" alt="error" />
            <div class="img-content">
              <h3>Plane 3</h3>
              <a
                href="https://skytraxratings.com/airlines/philippine-airlines-rating"
                class="btn btn-primary"
                target="blank"
                >learn more</a
              >
            </div>
          </div>
        </div>
      </div>
    </section>
    <section id="plane-menu">
      <h2 class="plane-menu-heading">Plane Menu</h2>
      <div class="plane-menu-container container">
        <div class="plane-menu-item">
          <div class="plane-img">
            <img src="https://i.postimg.cc/wTLMsvSQ/plane-menu1.jpg" alt="" />
          </div>
          <div class="plane-description">
            <h2 class="plane-titile">Plane Menu Item 1</h2>
            <p>
                This menu is an example of the food served on the plane.
            </p>
            <p class="plane-price">Price:  ₱350</p>
          </div>
        </div>

        <div class="plane-menu-item">
          <div class="plane-img">
            <img
              src="https://i.postimg.cc/sgzXPzzd/plane-menu2.jpg"
              alt="error"
            />
          </div>
          <div class="plane-description">
            <h2 class="plane-titile">Plane Menu Item 2</h2>
            <p>
             This menu is an example of the food served on the plane.
            </p>
            <p class="plane-price">Price: ₱440</p>
          </div>
        </div>
        <div class="plane-menu-item">
          <div class="plane-img">
            <img src="https://i.postimg.cc/8zbCtYkF/plane-menu3.jpg" alt="" />
          </div>
          <div class="plane-description">
            <h2 class="plane-titile">Plane Menu Item 3</h2>
            <p>
            This menu is an example of the food served on the plane.
            </p>
            <p class="plane-price"> ₱250</p>
          </div>
        </div>
        <div class="plane-menu-item">
          <div class="plane-img">
            <img src="https://i.postimg.cc/Yq98p5Z7/plane-menu4.jpg" alt="" />
          </div>
          <div class="plane-description">
            <h2 class="plane-titile">Plane Menu Item 4</h2>
            <p>
            This menu is an example of the food served on the plane.
            </p>
            <p class="plane-price">Price: ₱300</p>
          </div>
        </div>
        <div class="plane-menu-item">
          <div class="plane-img">
            <img src="https://i.postimg.cc/KYnDqxkP/plane-menu5.jpg" alt="" />
          </div>
          <div class="plane-description">
            <h2 class="plane-titile">Plane Menu Item 5</h2>
            <p>
            This menu is an example of the food served on the plane.
            </p>
            <p class="plane-price">Price: ₱200</p>
          </div>
        </div>
        <div class="plane-menu-item">
          <div class="plane-img">
            <img src="https://i.postimg.cc/Jnxc8xQt/plane-menu6.jpg" alt="" />
          </div>
          <div class="plane-description">
            <h2 class="plane-titile">Plane Menu Item 6</h2>
            <p>
            This menu is an example of the food served on the plane.
            </p>
            <p class="plane-price">Price: ₱550</p>
          </div>
        </div>
      </div>
    </section>
    <section id="developers">
      <h2 class="developer-title">Developer</h2>
      <div class="developer-container container">
        <div class="developer-box">
          <div class="customer-detail">
            <div class="customer-photo">
              <img src="alger.jpg" alt="" />
              <p class="customer-name">Algernon<br>Angeles</p>
            </div>
          </div>
          <div class="star-rating">
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
          </div>
          <p class="developer-text">
          Give a Man a Fish, and You Feed Him for a Day. Teach a Man To Fish, and You Feed Him for a Lifetime.
          </p>
         
        </div>
        <div class="developer-box">
          <div class="customer-detail">
            <div class="customer-photo">
              <img
                src="ash.jpg"
                alt=""
              />
              <p class="customer-name">Ashlee Cabrera</p>
            </div>
          </div>
          <div class="star-rating">
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
          </div>
          <p class="developer-text">
          It Always Seems Impossible Until It’s Done. You Can Do It.
          </p>
         
        </div>
        <div class="developer-box">
          <div class="customer-detail">
            <div class="customer-photo">
              <img
                src="kenji.jpg"
                alt=""
              />
              <p class="customer-name">Kenji<br>Cunanan</p>
            </div>
          </div>
          <div class="star-rating">
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
          </div>
          <p class="developer-text">
           Walk Slowly But Never Walk Backward.
          </p>
         
        </div>
        <div class="developer-box">
          <div class="customer-detail">
            <div class="customer-photo">
              <img
                src="ielmar.jpeg"
                alt=""
              />
              <p class="customer-name">Ielmar Candelaria</p>
            </div>
          </div>
          <div class="star-rating">
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
          </div>
          <p class="developer-text">
            Good Things Come For Those Who Wait.
          </p>
         
        </div>
        <div class="developer-box">
          <div class="customer-detail">
            <div class="customer-photo">
              <img
                src="emman.jpg"
                alt=""
              />
              <p class="customer-name">Emmanuelle Baustista</p>
            </div>
          </div>
          <div class="star-rating">
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
          </div>
          <p class="developer-text">
            Start Your Day With Positive Thinking.
          </p>
         
        </div>
        <div class="developer-box">
          <div class="customer-detail">
            <div class="customer-photo">
              <img src="Amarie.jpg" alt="" />
              <p class="customer-name">Amarie<br>Baculi</p>
            </div>
          </div>
          <div class="star-rating">
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
          </div>
          <p class="developer-text">
            The future Belongs To Those Who Believe in The beauty Of Theur Dreams.
          </p>
         
        </div>
      </div>
    </section>
    <section id="contact">
      <div class="contact-container container">
        <div class="contact-img">
          <img src="terminal.jpg" alt="" />
        </div>

        <div class="form-container">
          <h2>Contact Us</h2>
          <input type="text" placeholder="Your Name" />
          <input type="email" placeholder="E-Mail" />
          <textarea
            cols="30"
            rows="6"
            placeholder="Type Your Message"
          ></textarea>
          <a href="#" class="btn btn-primary">Submit</a>
        </div>
      </div>
    </section>
    <footer id="footer">
      <h2>&copy; 2024 MCC Airlines. All rights reserved.</h2>
    </footer>
  </body>
  <!-- 
    .................../ JS Code for smooth scrolling /...................... -->

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
     
      $("a").on("click", function (event) {
       
        if (this.hash !== "") {
          
          event.preventDefault();

         
          var hash = this.hash;

          
         
          $("html, body").animate(
            {
              scrollTop: $(hash).offset().top,
            },
            800,
            function () {
             
              window.location.hash = hash;
            }
          );
        } // End if
      });
    });
  </script>
</html>

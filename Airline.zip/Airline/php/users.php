<?php
session_start();
$role = isset($_SESSION['role']) ? $_SESSION['role'] : 'Unknown Role';
$adminName = isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin';

// Redirect if user is not an admin
if (strtolower($role) !== 'admin') {
    header("Location: ../Register/login.php");
    exit();
}

include('../Register/connection.php');

// Fetch users data including photo path, excluding password for security
$sql = "SELECT id, username, full_name, email, mobile_number, date_of_birth, gender, role, photo FROM users WHERE role != 'admin'";
$result = $conn->query($sql);

$users = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

// Check if delete action is requested
if (isset($_GET['action']) && $_GET['action'] == 'delete') {
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $deleteSql = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($deleteSql);
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            echo "<script>alert('Record deleted successfully');</script>";
        } else {
            echo "<script>alert('Error deleting record');</script>";
        }
        $stmt->close();
    } elseif (isset($_POST['selected_ids'])) {
        $idsToDelete = $_POST['selected_ids'];
        if (!empty($idsToDelete)) {
            $idPlaceholders = implode(',', array_fill(0, count($idsToDelete), '?'));
            $deleteSql = "DELETE FROM users WHERE id IN ($idPlaceholders)";
            $stmt = $conn->prepare($deleteSql);
            $stmt->bind_param(str_repeat('i', count($idsToDelete)), ...array_map('intval', $idsToDelete));
            if ($stmt->execute()) {
                echo "<script>alert('Records deleted successfully');</script>";
            } else {
                echo "<script>alert('Error deleting records');</script>";
            }
            $stmt->close();
        }
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

$conn->close();

$defaultPhotoPath = 'pf.jpeg'; 
$photoPath = isset($_SESSION['photo']) ? htmlspecialchars($_SESSION['photo']) : $defaultPhotoPath;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" href="LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="../css/users.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
            color: rgb(140, 140, 140);
        }
        h1 {
            color: rgb(140, 140, 140);
        }
        i {
            color: #3d3d3d;
            transition: .3s;
            font-size: 20px;
        }
        i:hover {
            color: #d80f0f;
        }
        button {
            margin-top: 15px;
            padding: 1rem;
            border: none;
            color: rgb(239, 239, 239);
            cursor: pointer;
            border-radius: 20px;
            background-color: #3d3d3d; 
            transition: .3s;
        }
        button:hover {
            background-color: #d80f0f; 
        }
        input[type="checkbox"] {
            transform: scale(1.4); 
        }
    </style>
</head>
<body>
<div class="admin-panel">
    <nav>
        <div class="profile-info">
            <img src="<?php echo htmlspecialchars($photoPath); ?>" alt="User Photo">
            <h2><?php echo htmlspecialchars($adminName); ?></h2>
        </div>
        <ul>
            <li class="dropdown">
                <a href="javascript:void(0)" id="targeted">Dashboard</a>
                <div class="dropdown-content">
                    <a href="admin.php">Home</a>
                    <a href="users.php">Users</a>
                    <a href="users_booking.php">Users booking</a>
                    <a href="profile.php">Profile</a>
                </div>
            </li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="main">
        <h1>Users List</h1>
        <form method="post" action="?action=delete">
            <table>
                <thead>
                    <tr>
                        <th>Select all<br><input type="checkbox" id="select_all"></th>
                        <th>Photo</th>
                        <th>Username</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Mobile Number</th>
                        <th>Date of Birth</th>
                        <th>Gender</th>
                        <th>Role</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><input type="checkbox" name="selected_ids[]" value="<?php echo $user['id']; ?>"></td>
                            <td><img src="<?php echo htmlspecialchars($user['photo'] ? $user['photo'] : $defaultPhotoPath); ?>" alt="User Photo" style="width: 50px; height: auto;"></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['mobile_number']); ?></td>
                            <td><?php echo htmlspecialchars($user['date_of_birth']); ?></td>
                            <td><?php echo htmlspecialchars($user['gender']); ?></td>
                            <td><?php echo htmlspecialchars($user['role']); ?></td>
                            <td><a href="?action=delete&id=<?php echo $user['id']; ?>" onclick="return confirm('Are you sure you want to delete this user?')"><i class='fa-solid fa-trash'></i></a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <button type="submit" onclick="return confirm('Are you sure you want to delete selected users?')">Delete Selected</button>
        </form>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', (event) => {
        const dropdown = document.querySelector('.dropdown');
        dropdown.addEventListener('click', () => {
            dropdown.classList.toggle('active');
        });

        const selectAllCheckbox = document.getElementById('select_all');
        const checkboxes = document.querySelectorAll('input[name="selected_ids[]"]');

        selectAllCheckbox.addEventListener('change', (e) => {
            checkboxes.forEach(checkbox => {
                checkbox.checked = e.target.checked;
            });
        });

        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                if (!checkbox.checked) {
                    selectAllCheckbox.checked = false;
                } else if (Array.from(checkboxes).every(checkbox => checkbox.checked)) {
                    selectAllCheckbox.checked = true;
                }
            });
        });
    });
</script>
</body>
</html>

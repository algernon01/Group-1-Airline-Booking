<?php
session_start();
require "config.php";

// Ensure the user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: ../Register/login.php");
    exit();
}

// Check if 'id' parameter is passed
if (!isset($_GET['id'])) {
    echo "Error: Booking ID not specified.";
    exit();
}

$bookingId = $_GET['id'];
$userId = $_SESSION['id'];

// Fetch booking details from the database
$selectSql = "SELECT * FROM bookings WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($selectSql);
$stmt->bind_param("ii", $bookingId, $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "Error: Booking not found or unauthorized access.";
    exit();
}

$row = $result->fetch_assoc();

// Close statement and connection
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Boarding Pass</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/print.css">
    <link rel="icon" href="LOGO.png" type="image/x-icon">
</head>
<body>
    <main>
        <div class="boarding-pass">
            <h2>Boarding Pass</h2>
            <div class="ticket">
                <div class="left">
                    <div class="logo"><img src="LOGO.png" alt="Logo"></div>
                    <div class="flight-details">
                        <span class="airline">MCC Airline</span>
                        <span class="flight">Flight: <?= htmlspecialchars($row["flight"]) ?></span>
                        <span class="gate">Gate: <?= htmlspecialchars($row["gate"]) ?></span>
                        <span class="seat">Seat: <?= htmlspecialchars($row["seat"]) ?></span>
                        <span class="boarding-time">Boarding Time: <?= htmlspecialchars(date('H:i:s', strtotime($row["boarding_time"]))) ?></span>
                    </div>
                </div>
                <div class="right">
                    <div class="route">
                        <span class="from"><?= htmlspecialchars($row["from_location"]) ?></span>
                        <span class="plane-icon"><i class="fa-solid fa-plane"></i></span>
                        <span class="to"><?= htmlspecialchars($row["to_location"]) ?></span>
                    </div>
                    <div class="passenger-details">
                        <span class="passenger-name">Passenger: <?= htmlspecialchars($row["full_name"]) ?></span>
                        <span class="date">Date: <?= htmlspecialchars($row["dateV"]) ?></span>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>

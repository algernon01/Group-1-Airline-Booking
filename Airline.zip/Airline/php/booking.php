<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Flight Booking</title>
    <link rel="icon" href="LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="../css/booking.css">
</head>
<body>
<nav class="navbar">
      <div class="navbar-container container">
          <input type="checkbox" name="" id="">
          <div class="hamburger-lines">
              <span class="line line1"></span>
              <span class="line line2"></span>
              <span class="line line3"></span>
          </div>
          <ul class="menu-items">
              <li><a href="home.php">Home</a></li>
              <li><a href="home.php">About</a></li>
              <li><a href="home.php">Category</a></li>
              <li><a href="home.php">Menu</a></li>
              <li><a href="home.php">developer</a></li>
              <li><a href="home.php">Contact</a></li>
              <li><a href="redirect.php">Booking</a></li>
              <li><a href="tickets.php">Flights</a></li>
              <li><a href="result.php">Result</a></li>
              <?php if (isset($_SESSION['user'])): ?>
                        <div class="profile">
                            <span><?= $_SESSION['user']; ?></span>
                            <div class="dropdown">
                            <?php
                        include('../Register/connection.php');
                        $user_id = $_SESSION['id'];
                        $sql = "SELECT photo FROM users WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $user_id);
                        $stmt->execute();
                        $stmt->bind_result($photoPath);
                        $stmt->fetch();
                        $stmt->close();
                        $conn->close();
                        
                        $photoPath = $photoPath ?: 'pf.jpeg';  
                        ?>
                        <img src="<?php echo htmlspecialchars($photoPath); ?>" class="hoverZoomLink" alt="User Photo">
                                <div class="dropdown-content">
                                    <a href="profile.php">Profile</a>
                                    <a href="logout.php">Logout</a>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <li class="login"><a href="../Register/login.php">Login</a></li>
                        <li><a href="../Register/Register.php">Sign In</a></li>
                    <?php endif; ?>
          </ul>
          <img src="LOGO.png" alt="Logo" id="logo" class ="logo">
      </div>
  </nav>
    <main>
        <h1>Online Flight Booking</h1>
        <div class="form-container">
            <form id="flightSearchForm" action="result.php" method="post" onsubmit="return validateSearchForm()">
                <div class="trip-type">
                    <input type="radio" id="roundTrip" name="tripType" value="roundTrip" checked>
                    <label for="roundTrip" style="margin-right: 10rem;">Round Trip</label>
                    <input type="radio" id="oneWay" name="tripType" value="oneWay">
                    <label for="oneWay">One Way</label>
                </div>
                <label for="fullName">Full Name</label>
                <input type="text" id="fullName" name="fullName" placeholder="Enter your full name">
                <label for="from">From</label>
                <select id="from" name="from" onchange="updatePrice()">
                    <option value="">From</option>
                    <option value="Manila">Manila (MNL)</option>
                    <option value="Cebu">Cebu (CEB)</option>
                    <option value="Davao">Davao (DVO)</option>
                    <option value="Clark">Clark (CRK)</option>
                    <option value="Iloilo">Iloilo (ILO)</option>
                    <option value="Kalibo">Kalibo (KLO)</option>
                    <option value="Tagbilaran">Tagbilaran (TAG)</option>
                    <option value="Zamboanga">Zamboanga (ZAM)</option>
                </select>
                <label for="to">To</label>
                <select id="to" name="to" onchange="updatePrice()">
                    <option value="">To</option>
                    <option value="Manila">Manila (MNL)</option>
                    <option value="Cebu">Cebu (CEB)</option>
                    <option value="Davao">Davao (DVO)</option>
                    <option value="Clark">Clark (CRK)</option>
                    <option value="Iloilo">Iloilo (ILO)</option>
                    <option value="Kalibo">Kalibo (KLO)</option>
                    <option value="Tagbilaran">Tagbilaran (TAG)</option>
                    <option value="Zamboanga">Zamboanga (ZAM)</option>
                </select>
                <label for="depart">Departure Date</label>
                <input type="date" id="depart" name="depart">
                <label for="return">Return Date</label>
                <input type="date" id="return" name="return">
                <label for="class">Class</label>
                <select id="class" name="travel_class" onchange="updatePrice()">
                    <option value="economy">Economy</option>
                    <option value="comfort">Comfort Class</option>
                </select>
                <label for="passenger">Passengers</label>
                <input type="number" id="passenger" name="passenger" value="1" min="1">
                <div class="price-display" id="priceDisplay"></div>
                <button type="submit">Search Flights</button>
            </form>
        </div>
    </main>
    <script src="../script/script.js"></script>
    <footer id="footer">
      <h2>&copy; 2024 MCC Airlines. All rights reserved.</h2>
    </footer>
</body>
</html>

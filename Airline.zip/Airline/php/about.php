<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - MCC Airlines</title>
    <link rel="stylesheet" href="../css/about.css">
</head>
<body>
    <div class="wrapper">
    <header>
            <nav>
                <img src="LOGO.png" alt="Logo" id="logo">
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="redirect.php">Booking</a></li>
                    <li><a href="contact.html">Flights</a></li>
                    <?php if (isset($_SESSION['user'])): ?>
                        <div class="profile">
                            <span><?= $_SESSION['user']; ?></span>
                            <div class="dropdown">
                            <img src="pf.jpeg" alt="" style="cursor: pointer;">
                                <div class="dropdown-content">
                                    <a href="profile.php">Profile</a>
                                    <a href="logout.php">Logout</a>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <li class="login"><a href="../Register/login.php">Login</a></li>
                        <li><a href="../Register/Register.php">Sign In</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </header>
        <main>
            <div class="container">
                <h1>About Us</h1>
                <p>MCC Airlines aims to revolutionize travel in the Philippines by providing exceptional experiences at affordable prices through our user-friendly website. Our mission is to enable everyone to explore the Philippines with economical airfares. As the pioneering airline of MCC, we proudly cater to all travelers within the Philippines, offering 24/7 booking assistance.</p>
                <p>We are committed to making travel accessible for all, ensuring that the beauty and diversity of the Philippines are within everyone’s grasp. Our dedication to you includes a seamless travel experience from booking to arrival, supported by our dedicated customer service team.</p>
            </div>
        </main>
        <div class="developer-section">
            <div class="card">
                <img src="ash.png" alt="Ashlee Cabrera">
                <div class="container">
                    <h4><b>Cabrera, Ashlee</b></h4>
                    <p>Architect & Engineer</p>
                </div>
            </div>
            <div class="card">
                <img src="ash.png" alt="Ashlee Cabrera">
                <div class="container">
                    <h4><b>Cabrera, Ashlee</b></h4>
                    <p>Architect & Engineer</p>
                </div>
            </div>
            <div class="card">
                <img src="ash.png" alt="Ashlee Cabrera">
                <div class="container">
                    <h4><b>Cabrera, Ashlee</b></h4>
                    <p>Architect & Engineer</p>
                </div>
            </div>
        </div>
        <div class="developer-section">
            <div class="card">
                <img src="ash.png" alt="Ashlee Cabrera">
                <div class="container">
                    <h4><b>Cabrera, Ashlee</b></h4>
                    <p>Architect & Engineer</p>
                </div>
            </div>
            <div class="card">
                <img src="ash.png" alt="Ashlee Cabrera">
                <div class="container">
                    <h4><b>Cabrera, Ashlee</b></h4>
                    <p>Architect & Engineer</p>
                </div>
            </div>
            <div class="card">
                <img src="ash.png" alt="Ashlee Cabrera">
                <div class="container">
                    <h4><b>Cabrera, Ashlee</b></h4>
                    <p>Architect & Engineer</p>
                </div>
            </div>
        </div>
        <footer>
            <div class="footer">
                <p>&copy; 2024 MCC Airlines. All rights reserved.</p>
            </div>
        </footer>
    </div>
</body>
</html>

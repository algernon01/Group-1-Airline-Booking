<?php
session_start();

if (isset($_SESSION['user'])) {
    header('Location: ../php/booking.php');
} else {
    header('Location: ../Register/login.php');
}
exit();
?>

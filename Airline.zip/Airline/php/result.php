<?php
session_start();
require_once "config.php";

function sanitizeInput($data) {
    return htmlspecialchars(strip_tags($data));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = sanitizeInput($_POST["fullName"]);
    $tripType = sanitizeInput($_POST["tripType"]);
    $from = sanitizeInput($_POST["from"]);
    $to = sanitizeInput($_POST["to"]);
    $depart = sanitizeInput($_POST["depart"]);
    $return = sanitizeInput($_POST["return"]);
    $travelclass = sanitizeInput($_POST["travel_class"]);
    $passenger = sanitizeInput($_POST["passenger"]);
    
    if(isset($_SESSION['id'])) {
        $userId = $_SESSION['id']; // Ensure session ID is set

        // Pricing array
        $pricing = [
            'Manila-Cebu' => ['economy' => [2000, 3000], 'comfort' => [3000, 5000]],
            'Manila-Davao' => ['economy' => [3000, 4500], 'comfort' => [4500, 6000]],
            'Manila-Clark' => ['economy' => [1500, 2500], 'comfort' => [2500, 4000]],
            'Manila-Iloilo' => ['economy' => [2500, 3500], 'comfort' => [3500, 5000]],
            'Manila-Kalibo' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Manila-Tagbilaran' => ['economy' => [3000, 4000], 'comfort' => [4000, 5500]],
            'Manila-Zamboanga' => ['economy' => [4000, 5000], 'comfort' => [5000, 6500]],
            'Cebu-Manila' => ['economy' => [2000, 3000], 'comfort' => [3000, 5000]],
            'Cebu-Davao' => ['economy' => [3500, 4500], 'comfort' => [4000, 5500]],
            'Cebu-Clark' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Cebu-Iloilo' => ['economy' => [2000, 3000], 'comfort' => [3500, 5000]],
            'Cebu-Kalibo' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Cebu-Tagbilaran' => ['economy' => [2500, 3500], 'comfort' => [3500, 5000]],
            'Cebu-Zamboanga' => ['economy' => [3500, 4500], 'comfort' => [4500, 6000]],
            'Davao-Manila' => ['economy' => [3000, 4500], 'comfort' => [4500, 6000]],
            'Davao-Cebu' => ['economy' => [3500, 4500], 'comfort' => [4000, 5500]],
            'Davao-Clark' => ['economy' => [3000, 4000], 'comfort' => [4000, 5500]],
            'Davao-Iloilo' => ['economy' => [3000, 4500], 'comfort' => [4500, 6000]],
            'Davao-Kalibo' => ['economy' => [3000, 4500], 'comfort' => [4500, 6000]],
            'Davao-Tagbilaran' => ['economy' => [3500, 5000], 'comfort' => [5000, 6500]],
            'Davao-Zamboanga' => ['economy' => [4000, 5000], 'comfort' => [5000, 6500]],
            'Clark-Manila' => ['economy' => [1500, 2500], 'comfort' => [2500, 4000]],
            'Clark-Cebu' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Clark-Davao' => ['economy' => [3000, 4000], 'comfort' => [4000, 5500]],
            'Clark-Iloilo' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Clark-Kalibo' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Clark-Tagbilaran' => ['economy' => [2500, 3500], 'comfort' => [3500, 5000]],
            'Clark-Zamboanga' => ['economy' => [3000, 4000], 'comfort' => [4000, 5500]],
            'Iloilo-Manila' => ['economy' => [2500, 3500], 'comfort' => [3500, 5000]],
            'Iloilo-Cebu' => ['economy' => [2000, 3000], 'comfort' => [3500, 5000]],
            'Iloilo-Davao' => ['economy' => [3000, 4500], 'comfort' => [4500, 6000]],
            'Iloilo-Clark' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Iloilo-Kalibo' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Iloilo-Tagbilaran' => ['economy' => [2500, 3500], 'comfort' => [3500, 5000]],
            'Iloilo-Zamboanga' => ['economy' => [3000, 4000], 'comfort' => [4000, 5500]],
            'Kalibo-Manila' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Kalibo-Cebu' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Kalibo-Davao' => ['economy' => [3000, 4500], 'comfort' => [4500, 6000]],
            'Kalibo-Clark' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Kalibo-Iloilo' => ['economy' => [2000, 3000], 'comfort' => [3000, 4500]],
            'Kalibo-Tagbilaran' => ['economy' => [2500, 3500], 'comfort' => [3500, 5000]],
            'Kalibo-Zamboanga' => ['economy' => [3000, 4000], 'comfort' => [4000, 5500]],
            'Tagbilaran-Manila' => ['economy' => [3000, 4000], 'comfort' => [4000, 5500]],
            'Tagbilaran-Cebu' => ['economy' => [2500, 3500], 'comfort' => [3500, 5000]],
            'Tagbilaran-Davao' => ['economy' => [3500, 5000], 'comfort' => [5000, 6500]],
            'Tagbilaran-Clark' => ['economy' => [2500, 3500], 'comfort' => [3500, 5000]],
            'Tagbilaran-Iloilo' => ['economy' => [2500, 3500], 'comfort' => [3500, 5000]],
            'Tagbilaran-Kalibo' => ['economy' => [2500, 3500], 'comfort' => [3500, 5000]],
            'Tagbilaran-Zamboanga' => ['economy' => [4000, 5000], 'comfort' => [5000, 6500]],
            'Zamboanga-Manila' => ['economy' => [4000, 5000], 'comfort' => [5000, 6500]],
            'Zamboanga-Cebu' => ['economy' => [3500, 4500], 'comfort' => [4500, 6000]],
            'Zamboanga-Davao' => ['economy' => [4000, 5000], 'comfort' => [5000, 6500]],
            'Zamboanga-Clark' => ['economy' => [3000, 4000], 'comfort' => [4000, 5500]],
            'Zamboanga-Iloilo' => ['economy' => [4000, 5000], 'comfort' => [5000, 6500]],
            'Zamboanga-Kalibo' => ['economy' => [3000, 4000], 'comfort' => [4000, 5500]],
            'Zamboanga-Tagbilaran' => ['economy' => [4000, 5000], 'comfort' => [5000, 6500]],
        ];
            
        $gate = [
            'Manila-Cebu' => ['gate' => 'A1'],
            'Manila-Davao' => ['gate' => 'B2'],
            'Manila-Clark' => ['gate' => 'C3'],
            'Manila-Iloilo' => ['gate' => 'D4'],
            'Manila-Kalibo' => ['gate' => 'E5'],
            'Manila-Tagbilaran' => ['gate' => 'F6'],
            'Manila-Zamboanga' => ['gate' => 'G7'],
            'Cebu-Manila' => ['gate' => 'H8'],
            'Cebu-Davao' => ['gate' => 'I9'],
            'Cebu-Clark' => ['gate' => 'J10'],
            'Cebu-Iloilo' => ['gate' => 'K11'],
            'Cebu-Kalibo' => ['gate' => 'L12'],
            'Cebu-Tagbilaran' => ['gate' => 'M13'],
            'Cebu-Zamboanga' => ['gate' => 'N14'],
            'Davao-Manila' => ['gate' => 'B32'],
            'Davao-Cebu' => ['gate' => 'Y9'],
            'Davao-Clark' => ['gate' => 'O15'],
            'Davao-Iloilo' => ['gate' => 'P16'],
            'Davao-Kalibo' => ['gate' => 'Q17'],
            'Davao-Tagbilaran' => ['gate' => 'R18'],
            'Davao-Zamboanga' => ['gate' => 'S19'],
            'Clark-Manila' => ['gate' => 'T20'],
            'Clark-Cebu' => ['gate' => 'U21'],
            'Clark-Davao' => ['gate' => 'P18'],
            'Clark-Iloilo' => ['gate' => 'V22'],
            'Clark-Kalibo' => ['gate' => 'W23'],
            'Clark-Tagbilaran' => ['gate' => 'X24'],
            'Clark-Zamboanga' => ['gate' => 'Y25'],
            'Iloilo-Manila' => ['gate' => 'D41'],
            'Iloilo-Cebu' => ['gate' => 'K18'],
            'Iloilo-Davao' => ['gate' => 'E16'],
            'Iloilo-Clark' => ['gate' => 'L22'],
            'Iloilo-Kalibo' => ['gate' => 'Z26'],
            'Iloilo-Tagbilaran' => ['gate' => 'A27'],
            'Iloilo-Zamboanga' => ['gate' => 'B28'],
            'Kalibo-Manila' => ['gate' => 'C29'],
            'Kalibo-Cebu' => ['gate' => 'D30'],
            'Kalibo-Davao' => ['gate' => 'E31'],
            'Kalibo-Clark' => ['gate' => 'M23'],
            'Kalibo-Iloilo' => ['gate' => 'Z23'],
            'Kalibo-Tagbilaran' => ['gate' => 'F32'],
            'Kalibo-Zamboanga' => ['gate' => 'G33'],
            'Tagbilaran-Manila' => ['gate' => 'H34'],
            'Tagbilaran-Cebu' => ['gate' => 'I35'],
            'Tagbilaran-Davao' => ['gate' => 'J36'],
            'Tagbilaran-Clark' => ['gate' => 'K37'],
            'Tagbilaran-Iloilo' => ['gate' => 'L38'],
            'Tagbilaran-Kalibo' => ['gate' => 'M39'],
            'Tagbilaran-Zamboanga' => ['gate' => 'N40'],
            'Zamboanga-Manila' => ['gate' => 'O41'],
            'Zamboanga-Cebu' => ['gate' => 'P42'],
            'Zamboanga-Davao' => ['gate' => 'Q43'],
            'Zamboanga-Clark' => ['gate' => 'R44'],
            'Zamboanga-Iloilo' => ['gate' => 'S45'],
            'Zamboanga-Kalibo' => ['gate' => 'T46'],
            'Zamboanga-Tagbilaran' => ['gate' => 'N29'],
        ];
        //random the date
        function randomDate($start, $end) {
            $randomTimestamp = mt_rand(strtotime($start), strtotime($end));
            return date('Y-m-d', $randomTimestamp);
        }
        $date = [
            'Manila-Cebu' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Manila-Davao' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Manila-Clark' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Manila-Iloilo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Manila-Kalibo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Manila-Tagbilaran' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Manila-Zamboanga' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Cebu-Manila' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Cebu-Davao' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Cebu-Clark' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Cebu-Iloilo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Cebu-Kalibo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Cebu-Tagbilaran' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Cebu-Zamboanga' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Davao-Manila' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Davao-Cebu' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Davao-Clark' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Davao-Iloilo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Davao-Kalibo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Davao-Tagbilaran' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Davao-Zamboanga' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Clark-Manila' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Clark-Cebu' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Clark-Davao' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Clark-Iloilo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Clark-Kalibo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Clark-Tagbilaran' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Clark-Zamboanga' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Iloilo-Manila' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Iloilo-Cebu' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Iloilo-Davao' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Iloilo-Clark' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Iloilo-Kalibo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Iloilo-Tagbilaran' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Iloilo-Zamboanga' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Kalibo-Manila' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Kalibo-Cebu' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Kalibo-Davao' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Kalibo-Clark' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Kalibo-Iloilo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Kalibo-Tagbilaran' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Kalibo-Zamboanga' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Tagbilaran-Manila' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Tagbilaran-Cebu' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Tagbilaran-Davao' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Tagbilaran-Clark' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Tagbilaran-Iloilo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Tagbilaran-Kalibo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Tagbilaran-Zamboanga' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Zamboanga-Manila' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Zamboanga-Cebu' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Zamboanga-Davao' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Zamboanga-Clark' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Zamboanga-Iloilo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Zamboanga-Kalibo' => ['date' => randomDate('2024-07-01', '2024-08-31')],
            'Zamboanga-Tagbilaran' => ['date' => randomDate('2024-07-01', '2024-08-31')],
        ];
        

        $flight = [
            'Manila-Cebu' => ['flight' => 'ABC123'],
            'Manila-Davao' => ['flight' => 'DEF456'],
            'Manila-Clark' => ['flight' => 'GHI789'],
            'Manila-Iloilo' => ['flight' => 'JKL012'],
            'Manila-Kalibo' => ['flight' => 'MNO345'],
            'Manila-Tagbilaran' => ['flight' => 'PQR678'],
            'Manila-Zamboanga' => ['flight' => 'STU901'],
            'Cebu-Manila' => ['flight' => 'VWX234'],
            'Cebu-Davao' => ['flight' => 'YZA567'],
            'Cebu-Clark' => ['flight' => 'BCD890'],
            'Cebu-Iloilo' => ['flight' => 'EFG123'],
            'Cebu-Kalibo' => ['flight' => 'HIJ456'],
            'Cebu-Tagbilaran' => ['flight' => 'KLM789'],
            'Cebu-Zamboanga' => ['flight' => 'NOP012'],
            'Davao-Manila' => ['flight' => 'QRS345'],
            'Davao-Cebu' => ['flight' => 'TUV678'],
            'Davao-Clark' => ['flight' => 'WXY901'],
            'Davao-Iloilo' => ['flight' => 'ZAB234'],
            'Davao-Kalibo' => ['flight' => 'CDE567'],
            'Davao-Tagbilaran' => ['flight' => 'FGH890'],
            'Davao-Zamboanga' => ['flight' => 'IJK123'],
            'Clark-Manila' => ['flight' => 'LMN456'],
            'Clark-Cebu' => ['flight' => 'OPQ789'],
            'Clark-Davao' => ['flight' => 'RST012'],
            'Clark-Iloilo' => ['flight' => 'UVW345'],
            'Clark-Kalibo' => ['flight' => 'XYZ678'],
            'Clark-Tagbilaran' => ['flight' => 'ABC901'],
            'Clark-Zamboanga' => ['flight' => 'DEF234'],
            'Iloilo-Manila' => ['flight' => 'GHI567'],
            'Iloilo-Cebu' => ['flight' => 'JKL890'],
            'Iloilo-Davao' => ['flight' => 'MNO123'],
            'Iloilo-Clark' => ['flight' => 'PQR456'],
            'Iloilo-Kalibo' => ['flight' => 'STU789'],
            'Iloilo-Tagbilaran' => ['flight' => 'VWX012'],
            'Iloilo-Zamboanga' => ['flight' => 'YZA345'],
            'Kalibo-Manila' => ['flight' => 'BCD678'],
            'Kalibo-Cebu' => ['flight' => 'EFG901'],
            'Kalibo-Davao' => ['flight' => 'HIJ234'],
            'Kalibo-Clark' => ['flight' => 'KLM567'],
            'Kalibo-Iloilo' => ['flight' => 'NOP890'],
            'Kalibo-Tagbilaran' => ['flight' => 'QRS012'],
            'Kalibo-Zamboanga' => ['flight' => 'TUV345'],
            'Tagbilaran-Manila' => ['flight' => 'WXY678'],
            'Tagbilaran-Cebu' => ['flight' => 'ZAB901'],
            'Tagbilaran-Davao' => ['flight' => 'CDE234'],
            'Tagbilaran-Clark' => ['flight' => 'FGH567'],
            'Tagbilaran-Iloilo' => ['flight' => 'IJK123'],
            'Tagbilaran-Kalibo' => ['flight' => 'LMN456'],
            'Tagbilaran-Zamboanga' => ['flight' => 'OPQ789'],
            'Zamboanga-Manila' => ['flight' => 'RST012'],
            'Zamboanga-Cebu' => ['flight' => 'UVW345'],
            'Zamboanga-Davao' => ['flight' => 'XYZ678'],
            'Zamboanga-Clark' => ['flight' => 'ABC901'],
            'Zamboanga-Iloilo' => ['flight' => 'DEF234'],
            'Zamboanga-Kalibo' => ['flight' => 'GHI567'],
            'Zamboanga-Tagbilaran' => ['flight' => 'KWI789'],
        ];
        $seat = [
            'Manila-Cebu' => ['seat' => 'A12'],
            'Manila-Davao' => ['seat' => 'B34'],
            'Manila-Clark' => ['seat' => 'C56'],
            'Manila-Iloilo' => ['seat' => 'D78'],
            'Manila-Kalibo' => ['seat' => 'E90'],
            'Manila-Tagbilaran' => ['seat' => 'F12'],
            'Manila-Zamboanga' => ['seat' => 'G34'],
            'Cebu-Manila' => ['seat' => 'H56'],
            'Cebu-Davao' => ['seat' => 'I78'],
            'Cebu-Clark' => ['seat' => 'J90'],
            'Cebu-Iloilo' => ['seat' => 'K12'],
            'Cebu-Kalibo' => ['seat' => 'L34'],
            'Cebu-Tagbilaran' => ['seat' => 'M56'],
            'Cebu-Zamboanga' => ['seat' => 'N78'],
            'Davao-Manila' => ['seat' => 'O90'],
            'Davao-Cebu' => ['seat' => 'P12'],
            'Davao-Clark' => ['seat' => 'Q34'],
            'Davao-Iloilo' => ['seat' => 'R56'],
            'Davao-Kalibo' => ['seat' => 'S78'],
            'Davao-Tagbilaran' => ['seat' => 'T90'],
            'Davao-Zamboanga' => ['seat' => 'U12'],
            'Clark-Manila' => ['seat' => 'V34'],
            'Clark-Cebu' => ['seat' => 'W56'],
            'Clark-Davao' => ['seat' => 'X78'],
            'Clark-Iloilo' => ['seat' => 'Y90'],
            'Clark-Kalibo' => ['seat' => 'Z12'],
            'Clark-Tagbilaran' => ['seat' => 'AB34'],
            'Clark-Zamboanga' => ['seat' => 'CD56'],
            'Iloilo-Manila' => ['seat' => 'EF78'],
            'Iloilo-Cebu' => ['seat' => 'GH90'],
            'Iloilo-Davao' => ['seat' => 'IJ12'],
            'Iloilo-Clark' => ['seat' => 'KL34'],
            'Iloilo-Kalibo' => ['seat' => 'MN56'],
            'Iloilo-Tagbilaran' => ['seat' => 'OP78'],
            'Iloilo-Zamboanga' => ['seat' => 'QR90'],
            'Kalibo-Manila' => ['seat' => 'ST12'],
            'Kalibo-Cebu' => ['seat' => 'UV34'],
            'Kalibo-Davao' => ['seat' => 'WX56'],
            'Kalibo-Clark' => ['seat' => 'YZ78'],
            'Kalibo-Iloilo' => ['seat' => 'CD90'],
            'Kalibo-Tagbilaran' => ['seat' => 'EF12'],
            'Kalibo-Zamboanga' => ['seat' => 'GH34'],
            'Tagbilaran-Manila' => ['seat' => 'IJ56'],
            'Tagbilaran-Cebu' => ['seat' => 'KL78'],
            'Tagbilaran-Davao' => ['seat' => 'MN90'],
            'Tagbilaran-Clark' => ['seat' => 'OP12'],
            'Tagbilaran-Iloilo' => ['seat' => 'QR34'],
            'Tagbilaran-Kalibo' => ['seat' => 'ST56'],
            'Tagbilaran-Zamboanga' => ['seat' => 'UV78'],
            'Zamboanga-Manila' => ['seat' => 'WX12'],
            'Zamboanga-Cebu' => ['seat' => 'YZ34'],
            'Zamboanga-Davao' => ['seat' => 'CD56'],
            'Zamboanga-Clark' => ['seat' => 'EF78'],
            'Zamboanga-Iloilo' => ['seat' => 'GH90'],
            'Zamboanga-Kalibo' => ['seat' => 'IJ12'],
            'Zamboanga-Tagbilaran' => ['seat' => 'UP74'],
        ];
        
        //random the time 
        function randomBoardingTime() {
            $hours = str_pad(mt_rand(0, 23), 2, '0', STR_PAD_LEFT);
            $minutes = str_pad(mt_rand(0, 59), 2, '0', STR_PAD_LEFT);
            $seconds = str_pad(mt_rand(0, 59), 2, '0', STR_PAD_LEFT);
            return "$hours:$minutes:$seconds";
        }
        
        $boardingTime = [
            'Manila-Cebu' => ['boarding_time' => randomBoardingTime()],
            'Manila-Davao' => ['boarding_time' => randomBoardingTime()],
            'Manila-Clark' => ['boarding_time' => randomBoardingTime()],
            'Manila-Iloilo' => ['boarding_time' => randomBoardingTime()],
            'Manila-Kalibo' => ['boarding_time' => randomBoardingTime()],
            'Manila-Tagbilaran' => ['boarding_time' => randomBoardingTime()],
            'Manila-Zamboanga' => ['boarding_time' => randomBoardingTime()],
            'Cebu-Manila' => ['boarding_time' => randomBoardingTime()],
            'Cebu-Davao' => ['boarding_time' => randomBoardingTime()],
            'Cebu-Clark' => ['boarding_time' => randomBoardingTime()],
            'Cebu-Iloilo' => ['boarding_time' => randomBoardingTime()],
            'Cebu-Kalibo' => ['boarding_time' => randomBoardingTime()],
            'Cebu-Tagbilaran' => ['boarding_time' => randomBoardingTime()],
            'Cebu-Zamboanga' => ['boarding_time' => randomBoardingTime()],
            'Davao-Clark' => ['boarding_time' => randomBoardingTime()],
            'Davao-Iloilo' => ['boarding_time' => randomBoardingTime()],
            'Davao-Kalibo' => ['boarding_time' => randomBoardingTime()],
            'Davao-Tagbilaran' => ['boarding_time' => randomBoardingTime()],
            'Davao-Zamboanga' => ['boarding_time' => randomBoardingTime()],
            'Clark-Manila' => ['boarding_time' => randomBoardingTime()],
            'Clark-Cebu' => ['boarding_time' => randomBoardingTime()],
            'Clark-Iloilo' => ['boarding_time' => randomBoardingTime()],
            'Clark-Kalibo' => ['boarding_time' => randomBoardingTime()],
            'Clark-Tagbilaran' => ['boarding_time' => randomBoardingTime()],
            'Clark-Zamboanga' => ['boarding_time' => randomBoardingTime()],
            'Iloilo-Kalibo' => ['boarding_time' => randomBoardingTime()],
            'Iloilo-Tagbilaran' => ['boarding_time' => randomBoardingTime()],
            'Iloilo-Zamboanga' => ['boarding_time' => randomBoardingTime()],
            'Kalibo-Manila' => ['boarding_time' => randomBoardingTime()],
            'Kalibo-Cebu' => ['boarding_time' => randomBoardingTime()],
            'Kalibo-Davao' => ['boarding_time' => randomBoardingTime()],
            'Kalibo-Tagbilaran' => ['boarding_time' => randomBoardingTime()],
            'Kalibo-Zamboanga' => ['boarding_time' => randomBoardingTime()],
            'Tagbilaran-Manila' => ['boarding_time' => randomBoardingTime()],
            'Tagbilaran-Cebu' => ['boarding_time' => randomBoardingTime()],
            'Tagbilaran-Davao' => ['boarding_time' => randomBoardingTime()],
            'Tagbilaran-Clark' => ['boarding_time' => randomBoardingTime()],
            'Tagbilaran-Iloilo' => ['boarding_time' => randomBoardingTime()],
            'Tagbilaran-Kalibo' => ['boarding_time' => randomBoardingTime()],
            'Tagbilaran-Zamboanga' => ['boarding_time' => randomBoardingTime()],
            'Zamboanga-Manila' => ['boarding_time' => randomBoardingTime()],
            'Zamboanga-Cebu' => ['boarding_time' => randomBoardingTime()],
            'Zamboanga-Davao' => ['boarding_time' => randomBoardingTime()],
            'Zamboanga-Clark' => ['boarding_time' => randomBoardingTime()],
            'Zamboanga-Iloilo' => ['boarding_time' => randomBoardingTime()],
            'Zamboanga-Kalibo' => ['boarding_time' => randomBoardingTime()],
        ];
        
        $route = "$from-$to";
        $gateValue = isset($gate[$route]['gate']) ? $gate[$route]['gate'] : '';
        $dateValue = isset($date[$route]['date']) ? $date[$route]['date'] : '';
        $flightValue = isset($flight[$route]['flight']) ? $flight[$route]['flight'] :'';
        $seatValue = isset($seat[$route]['seat']) ? $seat[$route]['seat'] : '';
        $boardingTimeValue = isset($boardingTime[$route]['boarding_time']) ? $boardingTime[$route]['boarding_time'] : '';

        if (array_key_exists($route, $pricing)) {
            $priceRange = $pricing[$route][$travelclass];
            $fare = ($priceRange[0] + $priceRange[1]) / 2;
        } else {
            $fare = 0; 
        }

        $sql = "INSERT INTO bookings (user_id, full_name, trip_type, from_location, to_location, departure_date, return_date, travel_class, passengers, fare, gate, dateV, flight, seat, boarding_time)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            die('Prepare failed: ' . $conn->error);
        }
        
        $bind = $stmt->bind_param("issssssssssssss", $userId, $fullName, $tripType, $from, $to, $depart, $return, $travelclass, $passenger, $fare, $gateValue, $dateValue, $flightValue, $seatValue, $boardingTimeValue);
        if ($bind === false) {
            die('Bind failed: ' . $stmt->error);
        }

        if ($stmt->execute()) {
            $_SESSION['booking_success'] = true; 
            $stmt->close();
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        } else {
            echo "<tr><td colspan='7'>Error: " . $sql . "<br>" . $conn->error . "</td></tr>";
        }
    }
}
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = sanitizeInput($_GET['id']);
    if(isset($_SESSION['id'])) {
        $userId = $_SESSION['id'];
        $deleteSql = "DELETE FROM bookings WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($deleteSql);
        $stmt->bind_param("ii", $id, $userId);
        if ($stmt->execute()) {
            echo "<script>alert('Record deleted successfully');</script>";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        } else {
            echo "<script>alert('Error deleting record');</script>";
        }
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Bookings</title>
    <link rel="icon" href="LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/result.css">
</head>
<body>
<nav class="navbar">
      <div class="navbar-container container">
          <input type="checkbox" name="" id="">
          <div class="hamburger-lines">
              <span class="line line1"></span>  
              <span class="line line2"></span>
              <span class="line line3"></span>
          </div>
          <ul class="menu-items">
              <li><a href="home.php">Home</a></li>
              <li><a href="home.php">About</a></li>
              <li><a href="home.php">Category</a></li>
              <li><a href="home.php">Menu</a></li>
              <li><a href="home.php">developer</a></li>
              <li><a href="home.php">Contact</a></li>
              <li><a href="redirect.php">Booking</a></li>
              <li><a href="tickets.php">Flights</a></li>
              <li><a href="result.php">Result</a></li>
              <?php if (isset($_SESSION['user'])): ?>
                        <div class="profile">
                            <span><?= $_SESSION['user']; ?></span>
                            <div class="dropdown">
                            <?php
                        include('../Register/connection.php');
                        $user_id = $_SESSION['id'];
                        $sql = "SELECT photo FROM users WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $user_id);
                        $stmt->execute();
                        $stmt->bind_result($photoPath);
                        $stmt->fetch();
                        $stmt->close();
                        $conn->close();
                        
                        $photoPath = $photoPath ?: 'pf.jpeg'; 
                        ?>
                        <img src="<?php echo htmlspecialchars($photoPath); ?>" class="hoverZoomLink" alt="User Photo">
                                <div class="dropdown-content">
                                    <a href="profile.php">Profile</a>
                                    <a href="logout.php">Logout</a>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <li class="login"><a href="../Register/login.php">Login</a></li>
                        <li><a href="../Register/Register.php">Sign In</a></li>
                    <?php endif; ?>
          </ul>
          <img src="LOGO.png" alt="Logo" id="logo" class ="logo">
      </div>
  </nav>
<h2>Flight Bookings</h2>
<table>
    <thead>
        <tr>
            <th>From</th>
            <th>To</th>
            <th>Departure Date</th>
            <th>Return Date</th>
            <th>Status</th>
            <th>Fare</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php
    if(isset($_SESSION['id'])) {
        include('config.php');
        $userId = $_SESSION['id']; 
        $selectSql = "SELECT id, departure_date, return_date, from_location, to_location, status, fare, travel_class FROM bookings WHERE user_id = ?";
        $stmt = $conn->prepare($selectSql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["from_location"] . "</td>";
                echo "<td>" . $row["to_location"] . "</td>";
                echo "<td>" . $row["departure_date"] . "</td>";
                echo "<td>" . $row["return_date"] . "</td>";
                echo "<td>" . $row["status"] . "</td>";
                echo "<td>₱" . number_format($row["fare"], 2) . "</td>";
                echo "<td>
                        <a href='../php/home.php?id=" . $row["id"] . "'><i class='fa-solid fa-plane'></i></a>
                        <a href='edit.php?id=" . $row["id"] . "'><i class='fa-solid fa-pen'></i></a>
                        <a href='?action=delete&id=" . $row["id"] . "' onclick='return confirm(\"Are you sure you want to delete this booking?\")'><i class='fa-solid fa-trash'></i></a>
                      </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No bookings found</td></tr>";
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "<tr><td colspan='7'>Error: User not logged in.</td></tr>";
    }
    ?>
    </tbody>
</table>
<footer id="footer">
      <h2 style =>&copy; 2024 MCC Airlines. All rights reserved.</h2>
    </footer>
</body>
</html>

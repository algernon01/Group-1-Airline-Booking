<?php
session_start();
$username = isset($_SESSION['user']) ? $_SESSION['user'] : 'Guest';
$role = isset($_SESSION['role']) ? $_SESSION['role'] : 'Unknown Role';


if ($role !== 'admin') {
    header("Location: ../Register/login.php"); 
    exit();
}

include('../Register/connection.php');


$user_id = $_SESSION['id']; 
$sql = "SELECT username, photo FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $photoPath);
$stmt->fetch();
$stmt->close();
$conn->close();


$defaultPhotoPath = 'pf.jpeg'; 
$photoPath = $photoPath ?: $defaultPhotoPath;


$totalBookings = 100; 
$completedBookings = 75; 
$bookingPercentage = ($completedBookings / $totalBookings) * 100;


$color = '#ff4d4d'; 
if ($bookingPercentage >= 50 && $bookingPercentage < 75) {
    $color = '#ffa500'; 
} elseif ($bookingPercentage >= 75) {
    $color = '#4caf50'; 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="icon" href="LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
    .circular-progress::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background: conic-gradient(
        <?php echo $color; ?> <?php echo $bookingPercentage; ?>%,
        #e6e6e6 <?php echo $bookingPercentage; ?>%
    );
}
    </style>
</head>
<body>
<div class="admin-panel">
    <nav>
        <div class="profile-info">
            <img src="<?php echo htmlspecialchars($photoPath); ?>" alt="User Photo">
            <h2><?php echo htmlspecialchars($username); ?></h2>
        </div>
        <ul>
            <li class="dropdown">
                <a href="javascript:void(0)">Dashboard</a>
                <div class="dropdown-content">
                    <a href="users.php" id="targeted">Users</a>
                    <a href="users_booking.php">Users booking</a>
                    <a href="profile.php">Profile</a>
                </div>
            </li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="main">
        <div class="card">
            <h3>Booking Completion</h3>
            <div class="circular-progress">
                <div class="value-container"><?php echo round($bookingPercentage); ?>%</div>
            </div>
        </div>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', (event) => {
        const dropdown = document.querySelector('.dropdown');
        const dropdownContent = document.querySelector('.dropdown-content');
        dropdown.addEventListener('click', () => {
            dropdown.classList.toggle('active');
        });
    });
</script>
</body>
</html>

<?php
session_start();
$username = isset($_SESSION['user']) ? $_SESSION['user'] : 'Guest';
$role = isset($_SESSION['role']) ? $_SESSION['role'] : 'Unknown Role';

include('../Register/connection.php');

// Fetch user data
$user_id = $_SESSION['id']; 
$sql = "SELECT username, photo, date_of_birth, creation_date FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $photoPath, $birthday, $accountDate);
$stmt->fetch();
$stmt->close();
$conn->close();

// Default values if not set in the database
$defaultPhotoPath = 'pf.jpeg'; // Set the path to your default photo
$photoPath = $photoPath ?: $defaultPhotoPath;
$birthday = $birthday ?: 'Unknown Birthday';
$accountDate = $accountDate ?: 'Unknown Date';

// Determine the correct redirect link based on the user's role
$goBackLink = ($role === 'admin') ? 'admin.php' : 'home.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="icon" href="LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="../css/profile.css">
</head>
<body>
<aside class="profile-card">
  <header>
    <!-- Avatar -->
    <a target="" href="#" style="text-decoration: none;">
        <img src="<?php echo htmlspecialchars($photoPath); ?>" class="hoverZoomLink" alt="User Photo">
    </a>

    <!-- Username and role -->
    <h1><?php echo htmlspecialchars($username); ?></h1>
    <h2><?php echo htmlspecialchars($role); ?></h2>
    <h3>Birthday: <?php echo htmlspecialchars($birthday); ?></h3>
    <h3>Account Created: <?php echo htmlspecialchars($accountDate); ?></h3>
  </header>

  <!-- Form to upload photo -->
  <div class="upload-photo">
    <form action="upload_photo.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
        <label for="file" class="custom-file-upload">Choose a profile photo</label>
        <input type="file" name="file" id="file" accept=".jpg, .jpeg, .png" >
        <input type="submit" name="submit" value="Upload Photo">
        <a href="<?php echo $goBackLink; ?>" class="button-link">Go Back</a>
    </form>
  </div>
</aside>

<script>
function validateForm() {
    var fileInput = document.getElementById('file');
    if (fileInput.value === '') {
        alert('Please select a file to upload.');
        return false;
    }
    return true;
}
</script>
</body>
</html>

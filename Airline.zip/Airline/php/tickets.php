<?php
session_start();
require "config.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boarding Pass</title>
    <link rel="icon" href="LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/tickets.css">
</head>
<body>
<nav class="navbar">
    <div class="navbar-container container">
        <input type="checkbox" name="" id="">
        <div class="hamburger-lines">
            <span class="line line1"></span>
            <span class="line line2"></span>
            <span class="line line3"></span>
        </div>
        <ul class="menu-items">
            <li><a href="home.php">Home</a></li>
            <li><a href="home.php">About</a></li>
            <li><a href="home.php">Category</a></li>
            <li><a href="home.php">Menu</a></li>
            <li><a href="home.php">developer</a></li>
            <li><a href="home.php">Contact</a></li>
            <li><a href="redirect.php">Booking</a></li>
            <li><a href="tickets.php">Flights</a></li>
            <li><a href="result.php">Result</a></li>
            <?php if (isset($_SESSION['user'])): ?>
                <div class="profile">
                    <span><?= htmlspecialchars($_SESSION['user']); ?></span>
                    <div class="dropdown">
                    <?php
                        include('../Register/connection.php');
                        $user_id = $_SESSION['id'];
                        $sql = "SELECT photo FROM users WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $user_id);
                        $stmt->execute();
                        $stmt->bind_result($photoPath);
                        $stmt->fetch();
                        $stmt->close();
                        $conn->close();
                        
                        $photoPath = $photoPath ?: 'pf.jpeg'; 
                    ?>
                        <img src="<?= htmlspecialchars($photoPath); ?>" class="hoverZoomLink" alt="User Photo">
                        <div class="dropdown-content">
                            <a href="profile.php">Profile</a>
                            <a href="logout.php">Logout</a>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <li class="login"><a href="../Register/login.php">Login</a></li>
                <li><a href="../Register/Register.php">Sign In</a></li>
            <?php endif; ?>
        </ul>
        <img src="LOGO.png" alt="Logo" id="logo" class="logo">
    </div>
</nav>
<main>
    <div class="boarding-pass">
        <h2>Boarding Pass</h2>
        <?php
        if (isset($_SESSION['id'])) {
            include('config.php');
            $userId = $_SESSION['id'];
            $selectSql = "SELECT full_name, from_location, to_location, departure_date, trip_type, return_date, travel_class, gate, dateV, flight, seat, boarding_time, id FROM bookings WHERE user_id = ?";
            $stmt = $conn->prepare($selectSql);
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="ticket">';
                    echo '<div class="left">';
                    echo '<div class="logo"><img src="LOGO.png" alt="Logo"></div>';
                    echo '<div class="flight-details">';
                    echo '<span class="airline">MCC Airline</span>';
                    echo '<span class="flight">Flight: ' . htmlspecialchars($row["flight"]) . '</span>';
                    echo '<span class="gate">Gate: ' . htmlspecialchars($row["gate"]) . '</span>';
                    echo '<span class="seat">Seat: ' . htmlspecialchars($row["seat"]) . '</span>';
                    echo '<span class="boarding-time">Boarding Time: ' . htmlspecialchars(date('H:i:s', strtotime($row["boarding_time"]))) . '</span>';
                    echo '</div>';
                    echo '</div>';
                    echo '<div class="right">';
                    echo '<div class="route">';
                    echo '<span class="from">' . htmlspecialchars($row["from_location"]) . '</span>';
                    echo '<span class="plane-icon"><i class="fa-solid fa-plane"></i></span>';
                    echo '<span class="to">' . htmlspecialchars($row["to_location"]) . '</span>';
                    echo '</div>';
                    echo '<div class="print-icon">';
                    echo "<a href='print_ticket.php?id=" . $row['id'] . "' target='_blank'><i class='fa-solid fa-print'></i></a>";
                    echo '</div>';
                    echo '<div class="passenger-details">';
                    echo '<span class="passenger-name">Passenger: ' . htmlspecialchars($row["full_name"]) . '</span>';
                    echo '<span class="date">Date: ' . htmlspecialchars($row["dateV"]) . '</span>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p>No bookings found</p>';
            }

            $stmt->close();
            $conn->close();
        } else {
            echo '<p>Error: User not logged in.</p>';
        }
        ?>
    </div>
</main>
<footer id="footer">
    <h2>&copy; 2024 MCC Airlines. All rights reserved.</h2>
</footer>
</body>
</html>

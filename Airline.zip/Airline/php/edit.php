<?php
include 'config.php';

$id = '';
$from = '';
$to = '';
$departure_date = '';
$return_date = '';


if (isset($_GET['id'])) {
    $id = $_GET['id'];


    $query = "SELECT * FROM bookings WHERE id = $id";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        $booking = $result->fetch_assoc();

        $from = $booking['from_location'];
        $to = $booking['to_location'];
        $departure_date = $booking['departure_date'];
        $return_date = $booking['return_date'];
    } else {
        echo "Booking not found.";
        exit();
    }

    $result->free();
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $from = $_POST['from'];
    $to = $_POST['to'];
    $departure_date = $_POST['departure_date'];
    $return_date = $_POST['return_date'];

    $query = "UPDATE bookings SET 
              from_location = '$from', 
              to_location = '$to', 
              departure_date = '$departure_date', 
              return_date = '$return_date' 
              WHERE id = $id";

    if ($conn->query($query) === TRUE) {
       
        header("Location: result.php?status=updated");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Booking</title>
    <link rel="icon" href="LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="../css/edit.css">
</head>
<body>
    <div class="form-container">
        <h1>Edit Booking</h1>
        <form method="POST" action="edit.php">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            
            <label for="from">From</label>
            <select id="from" name="from">
                <option value="">Select from</option>
                <option value="Manila" <?php if ($from === 'Manila') echo 'selected'; ?>>Manila (MNL)</option>
                <option value="Cebu" <?php if ($from === 'Cebu') echo 'selected'; ?>>Cebu (CEB)</option>
                <option value="Davao" <?php if ($from === 'Davao') echo 'selected'; ?>>Davao (DVO)</option>
                <option value="Clark" <?php if ($from === 'Clark') echo 'selected'; ?>>Clark (CRK)</option>
                <option value="Iloilo" <?php if ($from === 'Iloilo') echo 'selected'; ?>>Iloilo (ILO)</option>
                <option value="Kalibo" <?php if ($from === 'Kalibo') echo 'selected'; ?>>Kalibo (KLO)</option>
                <option value="Tagbilaran" <?php if ($from === 'Tagbilaran') echo 'selected'; ?>>Tagbilaran (TAG)</option>
                <option value="Zamboanga" <?php if ($from === 'Zamboanga') echo 'selected'; ?>>Zamboanga (ZAM)</option>
            </select>

            <label for="to">To</label>
            <select id="to" name="to">
                <option value="">Select to</option>
                <option value="Manila" <?php if ($to === 'Manila') echo 'selected'; ?>>Manila (MNL)</option>
                <option value="Cebu" <?php if ($to === 'Cebu') echo 'selected'; ?>>Cebu (CEB)</option>
                <option value="Davao" <?php if ($to === 'Davao') echo 'selected'; ?>>Davao (DVO)</option>
                <option value="Clark" <?php if ($to === 'Clark') echo 'selected'; ?>>Clark (CRK)</option>
                <option value="Iloilo" <?php if ($to === 'Iloilo') echo 'selected'; ?>>Iloilo (ILO)</option>
                <option value="Kalibo" <?php if ($to === 'Kalibo') echo 'selected'; ?>>Kalibo (KLO)</option>
                <option value="Tagbilaran" <?php if ($to === 'Tagbilaran') echo 'selected'; ?>>Tagbilaran (TAG)</option>
                <option value="Zamboanga" <?php if ($to === 'Zamboanga') echo 'selected'; ?>>Zamboanga (ZAM)</option>
            </select>

            <label for="departure_date">Departure Date</label>
            <input type="date" id="departure_date" name="departure_date" value="<?php echo $departure_date; ?>" required>

            <label for="return_date">Return Date</label>
            <input type="date" id="return_date" name="return_date" value="<?php echo $return_date; ?>" required>

            <button type="submit" class="submit-btn">Update Booking</button>
        </form>
    </div>
 <script src="../script/script.js"></script>
</body>
</html>

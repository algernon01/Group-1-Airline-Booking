<?php
$hostname = "localhost";
$username = "root";
$password = "";
$databasename = "registration_db";

// Create connection
$conn = mysqli_connect($hostname, $username, $password, $databasename);

// Check connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>

<?php
include('connection.php');

$useremail = "";
$password = "";
$remember_checked = false;

if (isset($_COOKIE['remember_user']) && isset($_COOKIE['remember_pass'])) {
    $useremail = $_COOKIE['remember_user'];
    $password = $_COOKIE['remember_pass'];
    $remember_checked = true;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $useremail = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $role = $_POST['role']; 

    $remember_checked = isset($_POST['remember']) ? true : false; 

    $error = "";

    if ($useremail != "" && $password != "") {
        $stmt = $conn->prepare("SELECT id, username, email, password, role FROM users WHERE (username = ? OR email = ?)");
        $stmt->bind_param("ss", $useremail, $useremail); 
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $username, $db_email, $hashed_password, $db_role);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                if ($role === 'admin' && $db_role === 'admin') { 
                    session_start();
                    $_SESSION['id'] = $id; 
                    $_SESSION['user'] = $username;
                    $_SESSION['role'] = $db_role; 

                    if ($remember_checked) {
                        setcookie('remember_user', $useremail, time() + (86400 * 30), "/"); 
                        setcookie('remember_pass', $password, time() + (86400 * 30), "/"); 
                    } else {
                        setcookie('remember_user', '', time() - 3600, "/");
                        setcookie('remember_pass', '', time() - 3600, "/");
                    }

                    unset($useremail);
                    unset($password);

                    header('Location: ../php/admin.php');
                    exit();
                } elseif ($role === 'user' && $db_role === 'user') {
                    session_start();
                    $_SESSION['id'] = $id; 
                    $_SESSION['user'] = $username;
                    $_SESSION['role'] = $db_role; 

                    if ($remember_checked) {
                        setcookie('remember_user', $useremail, time() + (86400 * 30), "/"); 
                        setcookie('remember_pass', $password, time() + (86400 * 30), "/"); 
                    } else {
                        setcookie('remember_user', '', time() - 3600, "/");
                        setcookie('remember_pass', '', time() - 3600, "/");
                    }

                    unset($useremail);
                    unset($password);

                    header('Location: ../php/home.php');
                    exit();
                } else {
                    $error = "Incorrect role selected for this account.";
                }
            } else {
                $error = "Incorrect password.";
            }
        } else {
            $error = "User does not exist.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/login.css">
</head>
<body>
    <div class="container">
        <div class="box">
            <div id="login" class="tab-content active">
                <h2>Login</h2>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" id="username" name="username" placeholder="Username or Email" value="<?= htmlspecialchars($useremail) ?>" required>
                        <?php if (!empty($error)): ?>
                        <div class="error"><?= $error; ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" id="password" name="password" placeholder="Password" value="<?= htmlspecialchars($password) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="role">Role:</label>
                        <select id="role" name="role" required style="width: 426px; padding: 0.75rem; border: 1px solid #ccc;border-radius: 5px;font-size: 1rem;">
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="checkbox" id="remember" name="remember" <?= $remember_checked ? 'checked' : '' ?>>
                        <label for="remember">Remember Me</label>
                    </div>
                    <button type="submit" class="btn">Login</button>
                </form>
                <p>Don't have an account? <a href="Register.php" style="text-decoration: none;">Create account</a></p>
            </div>
        </div>
    </div>
    <script>
function validateForm() {
    var fileInput = document.getElementById('file');
    if (fileInput.value === '') {
        alert('Please select a file to upload.');
        return false;
    }
    return true;
}
</script>

</body>
</html>

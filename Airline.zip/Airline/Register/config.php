<?php
    $conn = new mysqli('localhost', 'root', '', 'registration_db');
?>
<?php
include('connection.php');

$fullname = $username = $email = $password = $confirm_pass = $mobileNum = $dataBirth = $gender = $role = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = mysqli_real_escape_string($conn, $_POST['fullName']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['Password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['ConPassword']);
    $mobileNum = mysqli_real_escape_string($conn, $_POST['mobileNumber']);
    $dataBirth = mysqli_real_escape_string($conn, $_POST['bof']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    
    // Error handling
    $err = false;

    $result = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
    if (strlen($username) > 30) {
        $username = "Username is too long.";
        $err = true;
    } elseif (mysqli_num_rows($result) > 0) {
        $username = "Username already taken.";
        $err = true;
    }

    $result = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if (mysqli_num_rows($result) > 0) {
        $email = "Email already in use.";
        $err = true;
    }

    if (strlen($password) < 8) {
        $password = "Password must be at least 8 characters long.";
        $err = true;
    } elseif (!preg_match('/^(?=.*\d)(?=.*[\W_]).{8,}$/', $password)) {
        $password = "Password must include at least one number and a special character.";
        $err = true;
    }

    if ($password !== $confirm_password) {
        $confirm_pass = "Passwords do not match.";
        $err = true;
    }

    // Insert into db
    if (!$err) {
        // Password encryption
        $co_password = password_hash($password, PASSWORD_DEFAULT);
        $query = "INSERT INTO users (full_name, username, email, password, mobile_number, date_of_birth, gender) VALUES ('$fullname', '$username', '$email', '$co_password', '$mobileNum', '$dataBirth', '$gender')";
        if (mysqli_query($conn, $query)) {
            session_start();
            $_SESSION['user'] = $username;
            header('Location: login.php');
            exit();       
        } else {
            echo "Registration failed: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="../css/register.css">
    <style>
        .error {
            color: red;
            position: relative;
            left: 31rem;
            bottom: .8rem;
            display: inline-block;
        }
        .input-container {
            display: flex;
            align-items: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Registration <span> Form </span></h1>
        <form method="post" action="register.php">

            <div class="form-section">
                <h2>Personal Information</h2>
                <hr>

                <div class="section input-container">
                    <label for="fullName">Full Name:</label>
                    <input type="text" id="fullName" name="fullName" placeholder="Full Name" required>
                    <?php if (!empty($fullname)): ?>
                        <div class="error"><?= $fullname; ?></div>
                    <?php endif; ?>
                </div>

                <div class="section input-container">
                    <label for="username">User Name:</label>
                    <input type="text" id="username" name="username" placeholder="User Name" required>
                    <?php if (!empty($username)): ?>
                        <div class="error"><?= $username; ?></div>
                    <?php endif; ?>
                </div>

                <div class="section input-container">
                    <label for="Password">Password:</label>
                    <input type="password" id="Password" name="Password" placeholder="Password" required>
                    <?php if (!empty($password)): ?>
                        <div class="error"><?= $password; ?></div>
                    <?php endif; ?>
                </div>

                <div class="section input-container">
                    <label for="ConPassword">Confirm Password:</label>
                    <input type="password" id="ConPassword" name="ConPassword" placeholder="Confirm Password" required>
                    <?php if (!empty($confirm_pass)): ?>
                        <div class="error"><?= $confirm_pass; ?></div>
                    <?php endif; ?>
                </div>

                <div class="section input-container">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" placeholder="Email" required>
                    <?php if (!empty($email)): ?>
                        <div class="error"><?= $email; ?></div>
                    <?php endif; ?>
                </div>

                <div class="section input-container">
                    <label for="mobileNumber">Mobile Number:</label>
                    <input type="tel" id="mobileNumber" name="mobileNumber" placeholder="Mobile Number" required>
                </div>

                <div class="section input-container">
                    <label for="bof">Date of Birth:</label>
                    <input type="date" id="bof" name="bof" placeholder="Date of Birth" required>
                </div>

                <div class="section input-container">
                    <label for="gender">Gender:</label>
                    <div class="gender-row">
                        <label class="custom-checkbox">
                            <input type="radio" name="gender" value="male" required>
                            <span>Male</span>
                        </label>
                        <label class="custom-checkbox">
                            <input type="radio" name="gender" value="female" required>
                            <span>Female</span>
                        </label>
                    </div>
                </div>
            </div>

            <p style="margin-left: 25rem;">Already Have An Account? <a href="login.php" style="text-decoration: none">Login</a></p>
            <button type="submit" value="Submit">Submit</button>
        </form>
    </div>
</body>
</html>
